<template>
	<view>
		<view class="mian_img" :style="{height:startHeight}">
			<image src="/static/startup.png" mode="widthFix"></image>
			<view class="inst_btn" @click="goAppMian">立即进入</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				startHeight:''
			}
		},
		beforeCreate() {
			
		},
		onShow() {
			var that=this;
			uni.getSystemInfo({
				success:function(res){
					console.log(res)
					console.log(res.windowHeight)
					that.startHeight=res.windowHeight+'px'
				}
			})
		},
		methods: {
			//点击进入
			goAppMian(){
				console.log("78787")
				uni.reLaunch({
					url:'/pages/index/index'
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.mian_img{
		width: 100%;
		position: relative;
		overflow: hidden;
		image{
			width: 100%;
		}
		.inst_btn{
			position: absolute;
			width:343upx;
			height: 85upx;
			line-height: 85upx;
			border:1px solid $uni-color-A7E4D5;
			border-radius:43px;
			text-align: center;
			top: 813upx;
			left: 204upx;
			font-size: $uni-font-size-36;
			color: $uni-color-40CF9B;
		}
	}
</style>
