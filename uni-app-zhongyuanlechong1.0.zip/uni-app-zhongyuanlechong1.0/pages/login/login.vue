<template>
	<view>
		<view class="login_mian">
			<view class="logo"><image src="/static/plogo.png" mode="widthFix"></image></view>
			<view class="logincenter">
				<view class="login_tab">
					<view :class="activeCurrent==0?'active':''" @click="changeTab(0)">手机快捷登录</view>
					<view class="line"></view>
					<view :class="activeCurrent==1?'active':''" @click="changeTab(1)">账号密码登录</view>
				</view>
				<phone-login v-if="activeCurrent==0"></phone-login>
			</view>
		</view>
	</view>
</template>

<script>
	import phoneLogin from "../../components/logincomponents/phoneLogin.vue";
	export default {
		components:{
			'phone-login':phoneLogin
		},
		data() {
			return {
				activeCurrent:0
			}
		},
		beforeCreate() {
			
		},
		onShow() {
			
		},
		methods: {
			changeTab(index){
				this.activeCurrent=index
			}
		}
	}
</script>

<style lang="scss" scoped>
	.login_mian{
		.logo{
			text-align: center;
			margin-top: 135upx;
			image{
				width: 373upx;
			}
		}
		.logincenter{
			box-sizing: border-box;
			padding: 0 75upx;
			margin-top: 94upx;
			height: 677upx;
			.login_tab{
				display: flex;
				flex-direction: row;
				align-items: center;
				justify-content: space-around;
				>view{
					font-size: $uni-font-size-28;
				}
				.line{
					width: 1px;
					height: 26upx;
					background: $uni-color-D4D4D4;
				}
			}
		}
	}
	.active{
		color: $uni-color-3CCDA4;
	}
</style>
