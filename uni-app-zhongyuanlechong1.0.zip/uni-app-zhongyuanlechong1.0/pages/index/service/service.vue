<template>
	<view>
		<header-bar :isBack="true" titleTintColor="#fff" title="服务" :bgColor="{'background-image': 'linear-gradient(-45deg,rgba(56,203,173,1),rgba(64,207,155,1)'}">
		</header-bar>
		<view>
			<view>服务</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		computed: {
		    style() {
				console.log(this.statusBar)
		        let _style = `height: ${this.customBarH}px;`
		        return _style
		    },
			getmore(){
				console.log("hahah")
				return 1
			}
		},
		methods: {
			tabClick(e){
				console.log(e)
			}
		}
	}
</script>

<style lang="scss" scoped>
	
</style>
