<template>
	<view>
		<home-index v-if="tabIn==0"></home-index>
		<pile-find v-if="tabIn==1"></pile-find>
		<service-index v-if="tabIn==3"></service-index>
		<my-index v-if="tabIn==4"></my-index>
		<tab-bar :current="currentTabIndex" backgroundColor="#fbfbfb" color="#A7E4D5" tintColor="#40CF9B" @click="tabClick"></tab-bar>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				tabIn:4,
				currentTabIndex: 0,
			}
		},
		onLoad() {

		},
		onShow() {
			console.log("加密的---------")
			var data={
				id:1
			}
			console.log(this.$until.Encrypt(JSON.stringify(data)))
		},
		methods: {
			tabClick(e){
				console.log(e);
				if(e==2){
					console.log("需要扫一扫");
					uni.scanCode({
					    onlyFromCamera: true,
					    success: function (res) {
					        console.log('条码类型：' + res.scanType);
					        console.log('条码内容：' + res.result);
					    }
					});
				}else{
					this.tabIn=e;
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	
</style>
