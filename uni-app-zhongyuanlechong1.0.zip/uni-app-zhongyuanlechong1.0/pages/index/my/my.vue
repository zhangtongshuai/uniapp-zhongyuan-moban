<template>
	<view>
		<!-- <header-bar :isBack="true" titleTintColor="#fff" title="我的" :bgColor="{'background-image': 'linear-gradient(-45deg,rgba(56,203,173,1),rgba(64,207,155,1)'}">
		</header-bar> -->
		<!-- 头像信息区 -->
		<view class="userinfo">
			<image @click="toSetting" class="setting" src="/static/my/setting.png" mode=""></image>
			<view class="ava">
				<image src="/static/my/ava.png" mode=""></image>
			</view>
			<view class="nickname">
				<text>我是行行行</text>				
			</view>
			<view class="type">
				<text>普通用户</text>				
			</view>
		</view>
		<view class="info">
			<view class="li" @click="toMyBalance">
				<text>￥ 111.1</text>
				<text>余额</text>
			</view>
			<view class="li" @click="toMyCoupon">
				<text>19</text>
				<text>优惠券</text>
			</view>
			<view class="li" @click="toSysMsg">
				<text>1</text>
				<text>系统消息</text>
			</view>
		</view>
		<view class="hr"></view>
		<!-- 我的爱车 -->
		<view class="myCar">
			<view class="title">
				我的爱车
			</view>
			 <view class="addCar" v-if="false">
			 	<image src="@/static/my/addCar.png" mode=""></image>
				<text>添加爱车</text>
			 </view>
			 <view class="carInfo">
			 	<view class="left">
			 		<image src="@/static/my/ava.png" mode=""></image>
			 	</view>
				<view class="right">
					<view class="top">
						<text>我的车牌号</text>
						<text>撸B-123111</text>
					</view>
					<view class="bottom">
						<view>
							<text>12-20 13:11</text>
							<text>最近一次充电</text>
						</view>
						<view>
							<text>5小时30分</text>
							<text>上次充电使用时间</text>
						</view>
					</view>
				</view>
			 </view>
		</view>
		<view class="hr"></view>
		<!-- 我的服务 -->
		<view class="myService">
			<view class="title">
				我的服务
			</view>
			<view class="list">
				<view class="li" @click="toHistoryOrder">
					<image src="@/static/my/hidtoryOrder.png" mode=""></image>
					<text>历史订单</text>
				</view>
				<view class="li">
					<image src="@/static/my/inviteFriends.png" mode=""></image>
					<text>邀请好友</text>
				</view>
				<view class="li">
					<image src="@/static/my/place.png" mode=""></image>
					<text>申请合作场地</text>
				</view>
				<view class="li">
					<image src="@/static/my/beMaster.png" mode=""></image>
					<text>成为桩主</text>
				</view>
				<view class="li">
					<image src="@/static/my/bePartner.png" mode=""></image>
					<text>成为合伙人</text>
				</view>
				<view class="li">
					<image src="@/static/my/experience.png" mode=""></image>
					<text>桩主体验</text>
				</view>
				<view class="li">
					<image src="@/static/my/ad.png" mode=""></image>
					<text>广告投放</text>
				</view>
				<view class="li">
					<image src="@/static/my/help.png" mode=""></image>
					<text>历史订单</text>
				</view>
				<view class="li">
					<image src="@/static/my/feedback.png" mode=""></image>
					<text>意见反馈</text>
				</view>
			</view>
		</view>
		<view class="hr"></view>
		<!-- 合伙人服务 -->
		<view class="myService">
			<view class="title">
				合伙人服务
			</view>
			<view class="list">
				<view class="li">
					<image src="@/static/my/incomeDetail.png" mode=""></image>
					<text>收益明细</text>
				</view>
				<view class="li">
					<image src="@/static/my/masterList.png" mode=""></image>
					<text>桩主列表</text>
				</view>
				<view class="li">
					<image src="@/static/my/orderList.png" mode=""></image>
					<text>订单列表</text>
				</view>
				<view class="li">
					<image src="@/static/my/incomeWithdraw.png" mode=""></image>
					<text>收益提现</text>
				</view>
				<view class="li">
					<image src="@/static/my/personalInfor.png" mode=""></image>
					<text>个人信息</text>
				</view>
				<view class="li">
					<image src="@/static/my/ad2.png" mode=""></image>
					<text>广告申请</text>
				</view>				
			</view>
		</view>
		<view class="hr"></view>
		<!-- 桩主服务 -->
		<view class="myService">
			<view class="title">
				桩主服务
			</view>
			<view class="list">
				<view class="li">
					<image src="@/static/my/incomeDetail.png" mode=""></image>
					<text>收益明细</text>
				</view>
				<view class="li">
					<image src="@/static/my/masterList.png" mode=""></image>
					<text>充电桩列表</text>
				</view>
				<view class="li">
					<image src="@/static/my/orderList.png" mode=""></image>
					<text>订单列表</text>
				</view>
				<view class="li">
					<image src="@/static/my/incomeWithdraw.png" mode=""></image>
					<text>收益提现</text>
				</view>
				<view class="li">
					<image src="@/static/my/personalInfor.png" mode=""></image>
					<text>个人信息</text>
				</view>		
			</view>
		</view>
		<view class="hr"></view>
		<!-- 管理者服务 -->
		<view class="myService">
			<view class="title">
				管理者服务
			</view>
			<view class="list">
				<view class="li">
					<image src="@/static/my/partnerData.png" mode=""></image>
					<text>合伙人数据</text>
				</view>
				<view class="li">
					<image src="@/static/my/masterData.png" mode=""></image>
					<text>桩主数据</text>
				</view>
				<view class="li">
					<image src="@/static/my/chargeData.png" mode=""></image>
					<text>充电桩数据</text>
				</view>
				<view class="li">
					<image src="@/static/my/fundsData.png" mode=""></image>
					<text>资金数据</text>
				</view>
			</view>
		</view>
		<view class="hr"></view>
		<view class="hr"></view>
		<view class="hr"></view>
		<view class="hr"></view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		computed: {
		    style() {
				console.log(this.statusBar)
		        let _style = `height: ${this.customBarH}px;`
		        return _style
		    },
			getmore(){
				console.log("hahah");
				return 1
			}
		},
		methods: {
			tabClick(e){
				console.log(e)
			},
			// 设置页面
			toSetting:function() {
				uni.navigateTo({
					url:'/myPage/setting/setting'
				})
			},
			// 我的余额
			toMyBalance:function() {
				uni.navigateTo({
					url: '/myPage/myBalance/myBalance'
				})
			},
			// 我的优惠券
			toMyCoupon:function() {
				uni.navigateTo({
					url: '/myPage/myCoupon/myCoupon'
				})
			},
			// 系统消息
			toSysMsg:function() {
				uni.navigateTo({
					url: '/myPage/sysMsg/sysMsg'
				})
			},
			// 历史订单
			toHistoryOrder: function() {
				uni.navigateTo({
					url: '/myPage/myService/historyOrder'
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-color-FBF8FB !important;
	}
	// 头像信息区
	.userinfo {
		width: 750upx;
		height: 429upx;
		padding-top: 40upx;
		// padding-bottom: 30upx;
		// box-sizing: border-box;
		position: relative;
		background-color: $uni-color-ffffff;
		background-image: url(@/static/my/myBack.png);
		background-size: cover;
		border-top: 1upx solid $uni-color-40CF9B;
		.setting {
			position: absolute;
			width: 40upx;
			height: 40upx;
			/* #ifdef APP-PLUS */
			top: 63upx;			
			/* #endif */
			/* #ifdef MP-WEIXIN */
			top: 163upx;
			/* #endif */
			right: 30upx;
			z-index: 1;
		}
		.ava {
			width: 121upx;
			height: 121upx;
			text-align: center;
			border-radius: 50upx;
			margin: 83upx auto 30upx;
			margin-top: 83upx;
			text-align: center;
			image {
				width: 100%;
				height: 100%;
				border-radius: 50%;
			}
		}
		.nickname {
			text-align: center;
			color: $uni-color-ffffff;
			font-size: $uni-font-size-28;
			margin-bottom: 15upx;
		}
		.type {
			font-size: $uni-font-size-23;
			background-color: $uni-color-ffffff;
			color: $uni-color-40CF9B;
			width: 145upx;
			height: 32upx;
			// text-align: center;
			// line-height: 32upx;
			display: flex;
			align-items: center;
			justify-content: center;
			border-radius: 16upx;
			margin: 0 auto;
		}
	}
	.info {
		// padding: 31upx;
		box-sizing: border-box;
		display: flex;
		justify-content: space-around;
		position: relative;
		top: -50upx;
		background-color: $uni-color-ffffff;
		// position: absolute;
		// width: 100%;
		// bottom: 0;
		.li {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			width: 33.333%;
			text:first-child {
				color: $uni-color-40CF9B;
				font-size: $uni-font-size-28;
				margin-bottom: 20upx;
			}
			text:last-child {
				color: $uni-color-333;
				font-size: $uni-font-size-28;
			}
		}
		.li:nth-child(2) {
			border-left: 1upx solid $uni-color-E9E9E9;
			border-right: 1upx solid $uni-color-E9E9E9;
		}
	}
	.hr {
		width: 100%;
		height: 12upx;
		background-color: $uni-color-FBF8FB;
		position: relative;
		top: -20upx;
	}
	// 我的爱车
	.myCar {
		position: relative;
		top: -20upx;
		padding: 30upx;
		.title {
			font-size: $uni-font-size-32;
			color: $uni-color-333;
			margin-bottom: 20upx;
		}
		.addCar{
			height: 220upx;
			background: linear-gradient(to right,$uni-color-DEF7EE,$uni-color-AAEBD3);
			border: 1upx solid $uni-color-D6E9E5;
			border-radius: 10upx;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			image {
				width: 40upx;
				height: 40upx;
				margin-bottom: 30upx;
			}
			text {
				color: $uni-color-333;
				font-size: $uni-font-size-28;
			}
		}
		.carInfo {
			height: 220upx;
			background: linear-gradient(to right,$uni-color-DEF7EE,$uni-color-AAEBD3);
			border: 1upx solid $uni-color-D6E9E5;
			border-radius: 10upx;
			display: flex;
			padding: 30upx;
			align-items: center;
			box-sizing: border-box;
			color: $uni-color-333;
			.left {
				width: 150upx;
				height: 130upx;
				image {
					width: 100%;
					height: 100%;
				}
			}
			.right {
				width: 450upx;
				font-size: $uni-font-size-24;
				display: flex;
				flex-direction: column;
				justify-content: space-between;
				margin-left: 30upx;
				.top {
					display: flex;
					align-items: center;
					margin-bottom: 20upx;
					text:last-child {
						font-size:$uni-font-size-36;
						color: #000;
						margin-left: 30upx;
					}
				}
				.bottom {
					display: flex;
					justify-content: space-between;
					view {
						display: flex;
						flex-direction: column;
						text:first-child {
							margin-bottom: 10upx;
							font-size:$uni-font-size-32;
						}
					}
				}
			}
			
		}
	}
	// 我的服务
	.myService {
		position: relative;
		top: -20upx;
		.title {
			padding: 30upx;
			font-size: $uni-font-size-32;
			color: $uni-color-333;
		}
		.list {
			display: flex;
			flex-wrap: wrap;
			.li {
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				border: 1upx solid $uni-color-FBF8FB;
				width: 32.5%;
				height: 140upx;
				image {
					width: 32upx;
					height: 32upx;
					margin-bottom: 20upx;
				}
				text {
					font-size: $uni-font-size-24;
					color: $uni-color-333;
				}
			}
		}
	}
</style>
