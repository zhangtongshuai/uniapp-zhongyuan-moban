<template>
	<view>活动页面</view>
</template>

<script>
</script>

<style>
</style>
