<template>
	<view>
		<header-bar :isBack="true" titleTintColor="#fff" title="系统设置" :bgColor="{'background-image': 'linear-gradient(-45deg,rgba(56,203,173,1),rgba(64,207,155,1)'}">
		</header-bar>
		<view class="li">
			<view class="left">
				用户协议
			</view>
			<view class="right">
				<image src="../static/right.png" mode=""></image>
			</view>
		</view>
		<view class="li">
			<view class="left">
				用户隐私
			</view>
			<view class="right">
				<image src="../static/right.png" mode=""></image>
			</view>
		</view>
		<view class="hr"></view>
		<view class="li">
			<view class="left">
				版本号
			</view>
			<view class="right">
				<text>v.2.2</text>
				<image src="../static/right.png" mode=""></image>
			</view>
		</view>
		<view class="li">
			<view class="left">
				清除缓存
			</view>
			<view class="right">
				<image src="../static/right.png" mode=""></image>
			</view>
		</view>
		<view class="logout">
			退出登录
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-color-FBF8FB !important;
		// height: 100%;
	}
	.li {
		background-color: $uni-color-ffffff;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 40upx;
		box-sizing: border-box;
		font-size: $uni-font-size-32;
		color: $uni-color-333;
		border-bottom: 1upx solid $uni-color-F5F5F5;
		.right {
			display: flex;
			align-items: center;
			text {
				font-size: $uni-font-size-23;
				color: $uni-color-979497;
				margin-right: 15upx;
			}
			image {
				width: 18upx;
				height: 31upx;
			}
		}
	}
	.hr {
		height: 20upx;
		background-color: $uni-color-F5F5F5;
	}
	.logout {
		position: fixed;
		bottom: 40upx;
		margin: 0 auto;
		left: 0;
		right: 0;
		text-align: center;
		line-height: 88upx;
		color: $uni-color-ffffff;
		border-radius: 10upx;
		width: 690upx;
		height: 88upx;
		background: linear-gradient(to right,$uni-color-38CBAD,$uni-color-40CF9B);
	}
</style>
