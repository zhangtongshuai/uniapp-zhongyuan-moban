<template>
	<view>
		<header-bar :isBack="true" titleTintColor="#fff" title="历史订单" :bgColor="{'background': 'linear-gradient(-45deg,rgba(56,203,173,1),rgba(64,207,155,1)'}">
		</header-bar>
		<view class="list">
			<view class="li">
				<view class="top">
					<view>
						充电站
					</view>
					<view>
						2020-20-20 11：11
					</view>
				</view>
				<view class="bottom">
					<view class="item">
						<view>
							<image src="../static/type.png" mode=""></image>
							<text>充电桩类型</text>
						</view>
						<view>
							<text>直充</text>
							<text></text>
						</view>
					</view>
					<view class="item">
						<view>
							<image src="../static/time.png" mode=""></image>
							<text>充电时长</text>
						</view>
						<view>
							<text>100 </text>
							<text>MIN</text>
						</view>
					</view>
					<view class="item">
						<view>
							<image src="../static/type.png" mode=""></image>
							<text>充电桩类型</text>
						</view>
						<view>
							<text>19.5 </text>
							<text>RMB</text>
						</view>
					</view>
				</view>
			</view>
			<view class="li">
				<view class="top">
					<view>
						充电站
					</view>
					<view>
						2020-20-20 11：11
					</view>
				</view>
				<view class="bottom">
					<view class="item">
						<view>
							<image src="../static/type.png" mode=""></image>
							<text>充电桩类型</text>
						</view>
						<view>
							<text>直充</text>
							<text></text>
						</view>
					</view>
					<view class="item">
						<view>
							<image src="../static/time.png" mode=""></image>
							<text>充电时长</text>
						</view>
						<view>
							<text>100 </text>
							<text>MIN</text>
						</view>
					</view>
					<view class="item">
						<view>
							<image src="../static/type.png" mode=""></image>
							<text>充电桩类型</text>
						</view>
						<view>
							<text>19.5 </text>
							<text>RMB</text>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss" scoped>
	.list {
		width: 100%;
		/* #ifdef APP-PLUS */
		margin-top: -42upx;
		/* #endif */
		/* #ifdef MP-WEIXIN */
		margin-top: -12upx;
		/* #endif */
		padding: 30upx;
		box-sizing: border-box;
		background-color: $uni-color-F8F6F9 !important;
		.li {
			background: $uni-color-ffffff;
			padding: 30upx;
			box-sizing: border-box;
			border-radius: 10upx;
			margin-bottom: 30upx;
			.top {
				display: flex;
				justify-content: space-between;
				align-items: center;
				font-size: $uni-font-size-32;
				color: $uni-color-333;
				margin-bottom: 40upx;
				view:last-child {
					font-size: $uni-font-size-23;
				}
			}
			.bottom {
				display: flex;
				justify-content: space-between;
				image {
					width: 24upx;
					height: 24upx;
					margin-right: 10upx;
				}
				.item {
					width: 25%;
					view:first-child {
						font-size: $uni-font-size-24;
						color: $uni-color-666;
						margin-bottom: 20upx;
						text-align: center;
					}
					view:last-child {
						color: $uni-color-333;
						font-size: $uni-font-size-24;
						text-align: center;
						text:last-child {
							color: $uni-color-CAC7CA;
						}
					}
				}
				.item:last-child {
					view:last-child {
						text:first-child {
							color: $uni-color-FF1313;
						}
					}
				}
			}
		}
		.li:last-child {
			margin-bottom: 0;
		}
	}
</style>
