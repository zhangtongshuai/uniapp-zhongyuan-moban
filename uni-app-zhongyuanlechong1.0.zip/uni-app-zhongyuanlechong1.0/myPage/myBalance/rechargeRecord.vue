<template>
	<view>
		<header-bar :isBack="true" titleTintColor="#fff" title="充值记录" :bgColor="{'background-image': 'linear-gradient(-45deg,rgba(56,203,173,1),rgba(64,207,155,1)'}">
		</header-bar> 
		<view class="li balance">
			<view class="top">
				<view class="left">
					<image src="../static/recharge1.png" mode=""></image>
					<text>余额充值</text>
				</view>
				<view class="right">
					<text>￥</text>
					<text>19.9</text>
				</view>
			</view>
			<view class="bottom">
				<view>
					购买时间：2017-11-11
				</view>
			</view>
		</view>
		<view class="li">
			<view class="top">
				<view class="left">
					<image src="../static/recharge2.png" mode=""></image>
					<text>余额充值</text>
				</view>
				<view class="right">
					<text>￥</text>
					<text>19.9</text>
				</view>
			</view>
			<view class="bottom">
				<view class="margin">
					购买时间：2017-11-11
				</view>
				<view>
					结束时间：2017-11-11
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss" scoped>
	.li {
		padding: 30upx;
		box-sizing: border-box;
		border-bottom: 12upx solid $uni-color-E9E9E9;
		.top {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding-bottom: 30upx;
			border-bottom: 1upx solid $uni-color-E9E9E9;
			.left {
				font-size: $uni-font-size-32;
				color: $uni-color-333;
				image {
					width: 34upx;
					height: 34upx;
					margin-right: 20upx;
				}
			}
			.right {
				font-size: $uni-font-size-24;
			}
		}
		.bottom {
			font-size: $uni-font-size-26;
			color: $uni-color-666;
			padding-top: 30upx;
			.margin {
				margin-bottom: 15upx;
			}
		}
	}
	/* #ifdef APP-PLUS */
	.balance {
		padding-top: 0;
	}	
	/* #endif */
</style>
