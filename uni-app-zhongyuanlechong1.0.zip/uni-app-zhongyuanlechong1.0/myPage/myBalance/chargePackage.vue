<template>
	<view>
		<header-bar :isBack="true" titleTintColor="#fff" title="充电套餐" :bgColor="{'background': 'linear-gradient(-45deg,rgba(56,203,173,1),rgba(64,207,155,1)'}">
		</header-bar> 	
		<image class="header" src="../static/chargePackage.png" mode=""></image>
		<view class="title">
			<view>
				充电套餐
			</view>
			<view>
				全国通用，不限时长不限地点
			</view>
		</view>
		<view :scroll-x='true' class="list">
			<view class="li select">
				<view class="days">
					30天充电
				</view>
				<view class="price">
					<text>￥</text>
					<text>19.9</text>
					<text>￥191</text>
				</view>
				<view class="times">
					不限次数
				</view>
			</view>
			<view class="li">
				<view class="days">
					30天充电
				</view>
				<view class="price">
					<text>￥</text>
					<text>19.9</text>
					<text>￥191</text>
				</view>
				<view class="times">
					不限次数
				</view>
			</view>
			<view class="li">
				<view class="days">
					30天充电
				</view>
				<view class="price">
					<text>￥</text>
					<text>19.9</text>
					<text>￥191</text>
				</view>
				<view class="times">
					不限次数
				</view>
			</view>
		</view>
		<!-- 须知 -->
		<view class="needKnow">
			<view class="tit">
				充电套餐购买须知
			</view>
			<view class="content">
				充电套餐购买须知充电套餐购买须知充电套餐购买须知充电套餐购买须知
				充电套餐购买须知充电套餐购买须知充电套餐购买须知充电套餐购买须知
				充电套餐购买须知充电套餐购买须知充电套餐购买须知充电套餐购买须知
			</view>
		</view>
		<view class="footer">
			<view class="left">
				￥19.6
			</view>
			<view class="right">
				立即支付
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss" scoped>
	.header {
		width: 100%;
		height: 324upx;
		/* #ifdef APP-PLUS */
		margin-top: -42upx;
		/* #endif */
		/* #ifdef MP-WEIXIN */
		margin-top: -12upx;
		/* #endif */
	}
	.title {
		padding: 40upx 50upx;
		box-sizing: border-box;
		font-size: $uni-font-size-36;
		color: $uni-color-333;
		view:last-child {
			margin-top: 20upx;
			color: $uni-color-666;
			font-size: $uni-font-size-26;
		}
	}
	.list {
		white-space: nowrap; // 滚动必须加的属性
		height: 226upx;
		display: flex;
		padding: 0 45upx;
		box-sizing: border-box;
		justify-content: space-between;
		.li {
			dislay:inline-block;
			width: 198.8upx;
			height: 226upx;
			box-sizing: border-box;
			border: 1upx solid $uni-color-F2F2F2;
			border-radius: 10upx;
			.days {
				border-radius: 10upx;
				width: 100%;
				height: 76upx;
				padding: 20upx;
				box-sizing: border-box;
				background: $uni-color-F2F2F2;
				color: $uni-color-333;
				font-size: $uni-font-size-26;
			}
			.price {
				margin-top: 40upx;
				padding: 0 25upx;
				box-sizing: border-box;
				font-size: $uni-font-size-23;
				color: $uni-color-999;
				text:first-child {
					color: $uni-color-FF1313;
				}
				text:nth-child(2) {
					color: $uni-color-FF1313;
					font-size: $uni-font-size-29;
				}
				text:last-child {
					text-decoration: line-through;
				}
			}
			.times {
				font-size: $uni-font-size-26;
				color: $uni-color-666;
				padding: 0 25upx;
				margin-top: 20upx;
			}
		}
		.select {
			border: 1upx solid $uni-color-5BC0A0;
			.days {
				background: $uni-color-EEF9F8;
			}
		}
	}
	// 须知
	.needKnow {
		padding: 40upx 50upx;
		box-sizing: border-box;
		.tit {
			font-size: $uni-font-size-36;
			color: $uni-color-333;
			margin-bottom: 35upx;
		}
		.content {
			font-size: $uni-font-size-26;
			color: $uni-color-666;
		}
	}
	.footer {
		position: fixed;
		bottom: 0;
		width: 100%;
		height: 128upx;
		padding: 0 30upx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		box-sizing: border-box;
		border-top: 1upx solid $uni-color-F2F2F2;
		.left {
			color: $uni-color-FF1313;
			font-size: $uni-font-size-42;
		}
		.right {
			width: 486upx;
			height: 88upx;
			background: linear-gradient(to right,$uni-color-38CBAD,$uni-color-40CF9B);
			text-align: center;
			line-height: 88upx;
			color: $uni-color-ffffff;
			font-size: $uni-font-size-36;
		}
	}
</style>
