<template>
	<view>
		<header-bar :isBack="true" titleTintColor="#fff" title="充值结果" :bgColor="{'background-image': 'linear-gradient(-45deg,rgba(56,203,173,1),rgba(64,207,155,1)'}">
		</header-bar> 		
		<image src="../static/sucess.png" class="sucess" mode=""></image>
		<view class="sucessMsg">
			充值成功
		</view>
		<view class="time">
			2019年12月12日  15：11：11
		</view>
		<view class="infos">
			<view class="li">
				<text>本次充值</text>
				<text>1000.00元</text>
			</view>
			<view class="li">
				<text>可用余额</text>
				<text>1000.00元</text>
			</view>
			<view class="li">
				<text>付款方式</text>
				<image src="../static/wxPay.png" mode=""></image>
				<text>微信支付</text>
			</view>
		</view>
		<view class="footer" @click="backHome">
			返回首页
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			backHome:function() {
				uni.redirectTo({
					url:'../../pages/index/index'
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.sucess {
		display: block;
		width: 129upx;
		height: 129upx;
		margin: 95upx auto 40upx;
	}
	.sucessMsg {
		text-align: center;
		font-size: $uni-font-size-54;
		text-align: center;
		color: $uni-color-FF9313;
	}
	.time {
		color: $uni-color-999;
		text-align: center;
		margin: 25upx auto 75upx;
		font-size: $uni-font-size-29;
	}
	.infos {
		margin: 0 30upx;
		background: $uni-color-F5F5F5;
		padding: 30upx;
		box-sizing: border-box;
		font-size: $uni-font-size-24;
		color: $uni-color-666;
		.li {
			display: flex;
			align-items: center;
			margin-bottom: 35upx;
			text:first-child {
				margin-right: 35upx;
			}
			text:last-child {
				color: $uni-color-333;
			}
			image {
				width: 34upx;
				height: 34upx;
				margin-right: 8upx;
			}
		}
		.li:last-child {
			margin-bottom: 0;
		}
	}
	.footer {
		position: fixed;
		bottom: 40upx;
		margin: 0 auto;
		left: 0;
		right: 0;
		text-align: center;
		line-height: 88upx;
		color: $uni-color-ffffff;
		border-radius: 10upx;
		width: 690upx;
		height: 88upx;
		background: linear-gradient(to right,$uni-color-38CBAD,$uni-color-40CF9B);
	}
</style>
