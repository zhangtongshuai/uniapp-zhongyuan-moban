<template>
	<view class="main">
		<header-bar :isBack="true" titleTintColor="#fff" title="我的余额" :bgColor="{'background-image': 'linear-gradient(to right,$uni-color-38CBAD,$uni-color-40CF9B)'}">
		</header-bar> 	
		<view class="record">
			充值记录
		</view>
		<!-- 可用余额 -->
		<view class="balance">
			<view>
				可用余额（元）
			</view>
			<view>
				1221.11
			</view>
			<view>
				充值本金1111元，佣金得11元
			</view>
		</view>
		<!-- 套餐区 -->
		<view class="package" @click="toPackge">
			<view class="left">
				<view>
					充电套餐
				</view>
				<view>
					限时优惠进行中
				</view>
			</view>
			<view class="right">
				<text class="black">去购买</text>
				<text class="green"></text>
			</view>
		</view>
		<!-- 输入区 -->
		<view class="input">
			<text>￥</text>
			<input type="text" placeholder="请输入充值金额" />
		</view>
		<!-- 金额区 -->
		<view class="list">
			<view class="li select">
				30元
			</view>
			<view class="li">
				50元
			</view>
			<view class="li">
				100元
			</view>
			<view class="li">
				300元
			</view>
			<view class="li">
				500元
			</view>
			<view class="li">
				1000元
			</view>
		</view>
		<view class="real">
			<text>实际到账：</text>
			<text>30.00元</text>
		</view>
		<!-- 选择支付区 -->
		<view class="pay">
			<view class="li">
				<view class="left">
					<image src="../static/zfb.png" mode=""></image>
					<text>支付宝</text>
				</view>
				<view class="right">
					<image src="../static/select.png" mode=""></image>
				</view>
			</view>
			<view class="li">
				<view class="left">
					<image src="../static/wxPay.png" mode=""></image>
					<text>微信</text>
				</view>
				<view class="right">
					<image src="../static/unselect.png" mode=""></image>
				</view>
			</view>
		</view>
		<view class="footer">
			立即支付
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		onLoad:function(){
		},
		methods: {
			// 充电套餐
			toPackge:function() {
				uni.navigateTo({
					url:'./chargePackage'
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.main {
		padding-bottom: 100upx;
	}
	// 充值记录
	.record {
		font-size: $uni-font-size-28;
		color: $uni-color-ffffff;
		position: absolute;
		right: 30upx;
		/* #ifdef APP-PLUS */
		top: 70upx;		
		/* #endif */		
	}	
	// 可用余额
	.balance {
		height: 445upx;
		width: 100%;
		z-index: -1;
		position: absolute;
		top: 0;
		background: linear-gradient(to right,$uni-color-38CBAD,$uni-color-40CF9B);
		color: $uni-color-ffffff;
		view:first-child {
			font-size: $uni-font-size-26;
			margin-bottom: 20upx;
			text-align: center;
			margin-top: 174upx;
		}
		view:nth-child(2) {
			font-size: $uni-font-size-60;
			margin-bottom: 35upx;
			text-align: center;
		}
		view:last-child {
			font-size: $uni-font-size-24;
			text-align: center;
		}
	}
	// 套餐
	.package {
		margin:240upx auto 0;
		width: 690upx;
		height: 152upx;
		background-image: url(../static/package.png);
		background-size: cover;
		box-shadow: 0.1px 0.1px 0.3px $uni-color-0A0D2F;
		padding: 30upx;
		box-sizing: border-box;
		display: flex;
		justify-content: flex-end;
		align-items: center;
		.left {
			font-size: $uni-font-size-32;
			color: $uni-color-333;
			margin-right: 100upx;
			view:last-child {
				font-size: $uni-font-size-29;
				color: $uni-color-666;
				margin-top: 20upx;
			}
		}
		.right {
			position: relative;
			.black {
				font-size: $uni-font-size-28;
				color: $uni-color-ffffff;
				display: block;
				background-color: $uni-color-333;
				text-align: center;
				width: 121upx;
				height: 51upx;
				line-height: 51upx;
				margin-right: 15upx;
				position: relative;
				z-index: 999;
				border-radius: 10upx;
			}
			.green {
				border-radius: 10upx;
				width: 34upx;
				height: 41upx;
				background: linear-gradient(to right,$uni-color-38CBAD,$uni-color-40CF9B);
				position: absolute;
				right: 0;
				top: -14upx;
				z-index: 0;
			}
		}
	}
	.input {
		margin: 50upx 40upx 0upx;
		padding-bottom: 30upx;
		display: flex;
		justify-content: space-between;
		border-bottom: 1upx solid $uni-color-E6E6E6;
		text {
			font-size: $uni-font-size-36;
			color: $uni-color-333;
			font-weight: bold;
		}
		input {
			text-align: right;
			font-size: $uni-font-size-32;
		}
	}
	// 金额区
	.list {
		padding: 40upx;
		padding-bottom: 0;
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		.li {
			width: 200upx;
			height: 100upx;
			border: 1upx solid $uni-color-F2F2F2;
			text-align: center;
			line-height: 100upx;
			box-sizing: border-box;
			text-align: center;
			font-size: $uni-font-size-30;
			margin-bottom: 25upx;
		}
		.select {
			background-color: $uni-color-F6FCFC;
			color: $uni-color-38CBAD;
			border: 1upx solid $uni-color-38CBAD;
		}
	}
	.real {
		text-align: right;
		font-size: $uni-font-size-30;
		color: $uni-color-333;
		font-weight: bold;
		margin: 20upx 40upx 50upx;
		text:last-child {
			color: $uni-color-38CBAD;
		}
	}
	// 选择支付区
	.pay {
		padding: 0 40upx 40upx;
		.li {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin-bottom: 50upx;
			.left {
				font-size: $uni-font-size-30;
				color: $uni-color-333;
				display: flex;
				align-items: center;
				image {
					width: 40upx;
					height: 40upx;
					margin-right: 25upx;
				}
			}
			.right {
				image {
					width: 26upx;
					height: 26upx;
				}
			}
		}
	}
	.footer {
		position: fixed;
		bottom: 40upx;
		margin: 0 auto;
		left: 0;
		right: 0;
		text-align: center;
		line-height: 88upx;
		color: $uni-color-ffffff;
		border-radius: 10upx;
		width: 690upx;
		height: 88upx;
		background: linear-gradient(to right,$uni-color-38CBAD,$uni-color-40CF9B);
	}
</style>
