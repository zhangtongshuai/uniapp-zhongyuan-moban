<template>
	<view>
		<header-bar :isBack="true" titleTintColor="#fff" title="我的优惠券" :bgColor="{'background': 'linear-gradient(-45deg,rgba(56,203,173,1),rgba(64,207,155,1)'}">
		</header-bar> 	
		<view class="tabs">
			<view class="tab select">
				可使用
			</view>
			<view class="tab">
				已失效
			</view>
		</view>
		<view class="list">
			<view class="li">
				<view class="left">
					全场优惠券
				</view>
				<view class="center">
					<view class="top">
						<text>30元</text>
						<text>抵用券</text>
					</view>
					<view class="middle">
						满31减30元
					</view>
					<view class="bottom">
						使用期限：2010/12/11~2010/11/11
					</view>
				</view>
				<view class="right">
					<text>
						立即使用
					</text>
				</view>
			</view>
			<view class="li used">
				<view class="left">
					全场优惠券
				</view>
				<view class="center">
					<view class="top">
						<text>30元</text>
						<text>抵用券</text>
					</view>
					<view class="middle">
						满31减30元
					</view>
					<view class="bottom">
						使用期限：2010/12/11~2010/11/11
					</view>
				</view>
				<view class="right">
					<text>
						已使用
					</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss" scoped>
	page {
		background-color: $uni-color-F8F6F9 !important;
	}
	.tabs {
		width: 100%;
		height: 88upx;
		display: flex;
		justify-content: center;
		align-items: center;
		/* #ifdef APP-PLUS */
		margin-top: -42upx;
		/* #endif */
		/* #ifdef MP-WEIXIN */
		margin-top: -12upx;
		/* #endif */
		background-color: $uni-color-ffffff;
		// margin-bottom: 30upx;
		.tab {
			color: $uni-color-333;
			font-size: $uni-font-size-24;
		}
		.tab:first-child {
			margin-right: 160upx;
		}
		.select {
			font-size: $uni-font-size-30;
			color: $uni-color-38CBAD;
		}
		
	}
	.list {
		padding: 30upx;
		box-sizing: border-box;
		background-color: $uni-color-F8F6F9 !important;
		.li {
			display: flex;
			width: 690upx;
			height: 167upx;
			background: url(../static/coupon.png);
			background-size: cover;
			margin-bottom: 30upx;
			.left {
				width: 60upx;
				height: 166upx;
				text-align: center;
				line-height: 60upx;
				writing-mode: vertical-rl;
				font-size: $uni-font-size-24;
				color: #FFFFFF;
			}
			.center {
				padding: 30upx;
				width: 444upx;
				height: 167upx;
				box-sizing: border-box;
				.top {
					font-size: $uni-font-size-32;
					color: $uni-color-FF1313;
					margin-bottom: 20upx;
					text:last-child {
						color: $uni-color-333;
					}
				}
				.middle {
					font-size: $uni-font-size-24;
					color: $uni-color-333;
					margin-bottom: 10upx;
				}
				.bottom {
					color: $uni-color-999;
					font-size: $uni-font-size-23;
				}
			}
			.right {
				width: 185upx;
				height: 167upx;
				display: flex;
				justify-content: center;
				align-items: center;
				text {
					width: 126upx;
					height: 50upx;
					color: $uni-color-ffffff;
					font-size: $uni-font-size-24;
					background: linear-gradient(to right,$uni-color-38CBAD,$uni-color-40CF9B);
					text-align: center;
					/* #ifdef APP-PLUS */
					line-height: 20upx;					
					/* #endif */
					/* #ifdef MP-WEIXIN */
					line-height: 50upx;	
					/* #endif */
					border-radius: 5upx;
				}
			}
		}
		.li:last-child {
			margin-bottom: 0upx;
		}
		.used {
			background: url(../static/coupon2.png);
			background-size: cover;
			.right{
				text {
					background: $uni-color-CDCDCD !important;
				}
			}
		}
	}
</style>
