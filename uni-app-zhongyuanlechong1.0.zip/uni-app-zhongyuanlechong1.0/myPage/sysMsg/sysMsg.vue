<template>
	<view>
		<header-bar :isBack="true" titleTintColor="#fff" title="系统消息" :bgColor="{'background': 'linear-gradient(-45deg,rgba(56,203,173,1),rgba(64,207,155,1)'}">
		</header-bar>
		<view class="list">
			<view class="li" @click="toDetail">
				<image src="../static/chargePackage.png" mode=""></image>
				<view class="con">
					<view class="left">
						<view class="title">
							充电桩的使用说明
						</view>
						<view class="time">
							2019-11-11
						</view>						
					</view>
					<view class="right">
						<image src="../static/right.png" mode=""></image>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		methods:{
			toDetail:function() {
				uni.navigateTo({
					url: './msgDetail'
				})
			}
		}
	}
</script>

<style lang="scss">
	.list {
		padding: 30upx;
		box-sizing: border-box;
		background-color: $uni-color-F8F6F9 !important;
		.li {
			width: 690upx;
			border-radius: 10upx;
			&>image {
				border-top-left-radius: 10upx;
				border-top-right-radius: 10upx;
				width: 690upx;
				height: 324upx;
			}
			.con {
				width: 100%;
				height: 118upx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 25upx 30upx;
				background-color: $uni-color-ffffff;
				box-sizing: border-box;
				box-shadow: 0.1px 0.1px 0.3px $uni-color-0A0D2F;
				border-bottom-left-radius: 10upx;
				border-bottom-right-radius: 10upx;
				.left {
					display: flex;
					flex-direction: column;
					justify-content: space-between;
					.title {
						font-size: $uni-font-size-32;
						color: $uni-color-333;
						margin-bottom: 20upx;
					}
					.time {
						font-size: $uni-font-size-23;
						color: $uni-color-666;
					}
				}
				.right {
					image {
						width: 18upx;
						height: 30upx;
					}
				}
			}
		}
	}
</style>
