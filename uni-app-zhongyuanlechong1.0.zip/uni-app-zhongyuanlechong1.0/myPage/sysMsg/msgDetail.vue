<template>
	<view>
		<header-bar :isBack="true" titleTintColor="#fff" title="我的消息" :bgColor="{'background': 'linear-gradient(-45deg,rgba(56,203,173,1),rgba(64,207,155,1)'}">
		</header-bar>
		<image class="img" src="../static/chargePackage.png" mode=""></image>
		<view class="content">
			<rich-text :nodes="msg"></rich-text>			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				msg: 'aaaaaa'
			};
		}
	}
</script>

<style lang="scss">
	.img {
		width: 100%;
		height: 324upx;
		/* #ifdef APP-PLUS */
		margin-top: -42upx;
		/* #endif */
		/* #ifdef MP-WEIXIN */
		margin-top: -12upx;
		/* #endif */
	}
	.content {
		padding: 50upx;
		rich-text {
			box-sizing: border-box;
		}		
	}
</style>
