import Vue from 'vue'
import App from './App'
import until from 'common/util.js'
import tabBar from './components/tabbar.vue'
import headerBar from './components/navCommon.vue'
import homeIndex from 'pages/index/home/home.vue'
import pileFind from 'pages/index/pileFind/pileFind.vue'
import serviceIndex from 'pages/index/service/service.vue'
import myIndex from 'pages/index/my/my.vue'


Vue.config.productionTip = false
Vue.component('tab-bar', tabBar)
Vue.component('header-bar', headerBar)
Vue.component('home-index', homeIndex)
Vue.component('pile-find', pileFind)
Vue.component('service-index', serviceIndex)
Vue.component('my-index', myIndex)

App.mpType = 'app'

Vue.prototype.$until = until;
Vue.prototype.$baseUrl = ''; 

const app = new Vue({
    ...App
})
app.$mount()
