<template>
	<view>
		<view style="height: 100upx;"></view>
		<view class="tab">
			<view v-for="(item,index) in tabList" :key="index">
				<view class="navigator" :class="currentTabIndex == index ? 'on' : ''" @tap="switchTab(index)" v-if="index!=2">
					<view class="icon">
						<image :src="item.iconselect" style="width: 32upx;height: 32upx;" v-if="currentTabIndex == index"></image>
						<image :src="item.icon" style="width: 32upx;height: 32upx;" v-else></image>
					</view>
					<view class="text" :style="[currentTabIndex == index ? {'color': tintColor} : {'color': color}]">{{item.text}}</view>
				</view>
				<view class="navigator" :class="currentTabIndex == index ? 'on' : ''" @tap="switchTab(index)" v-if="index==2">
					<view class="center_tab">
						<image src="/static/tabimg/icon_sacn.png"></image>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				tabList: [
					{
						iconselect:'/static/tabimg/index01.png',
						icon: '/static/tabimg/index02.png',
						text: '首页',
						//badge: 1,
						badgeDot: false
					},
					{
						iconselect:'/static/tabimg/find01.png',
						icon: '/static/tabimg/find02.png',
						text: '找桩',
						badgeDot: false
					},
					
					{
						iconselect:'/static/tabimg/find01.png',
						icon: '/static/tabimg/find02.png',
						text: '服务',
						badgeDot: false
					},
					{
						iconselect:'/static/tabimg/service01.png',
						icon: '/static/tabimg/service02.png',
						text: '服务',
						badgeDot: false
					},
					
					{
						iconselect:'/static/tabimg/my01.png',
						icon: '/static/tabimg/my02.png',
						text: '我的',
						badgeDot: false
					}
				],
				currentTabIndex: this.current
			}
		},
		props: {
			current: { type: [Number, String], default: 0 },
			backgroundColor: { type: String, default: '#fbfbfb' },
			color: { type: String, default: '#999' },
			tintColor: { type: String, default: '#42b983' }
		},
		methods: {
			switchTab(index){
				if(index!=2){
					this.currentTabIndex = index
				}
				this.$emit('click', index)
			}
		},
	}
</script>

<style scoped lang="scss">
	.tab{
		width: 100%;
		display: flex;
		background: $uni-color-ffffff;
		flex-direction: row;
		justify-content: space-around;
		position: fixed;
		bottom: -20upx;
		padding-top: 6upx;
		/*#ifdef MP-WEIXIN*/
		padding-top: 14upx;
		bottom: -30upx;
		/*#endif*/
		box-shadow: 1px -1px 10px $uni-color-40CF9B-02;
		.icon{
			text-align: center;
		}
		.text{
			font-size:$uni-font-size-24;
		}
		.center_tab{
			width: 113upx;
			height: 113upx;
			padding: 15upx;
			padding-bottom: 0;
			border-radius: 50%;
			background:$uni-color-ffffff;
			box-sizing: border-box;
			box-shadow: 0 -2px 8upx -1px $uni-color-40CF9B-02;
			position: relative;
			top: -20upx;
			/*#ifdef MP-WEIXIN*/
			top: -30upx;
			/*#endif*/
			text-align: center;
			>image{
				width: 82upx;
				height: 82upx;
			}
		}
	}
	
</style>
