<template>
	<view class="">
		<view class="uni_topbar" :style="style">
		    <view class="inner flexbox flex_alignc" :class="[fixed ? 'fixed' : '']" :style="[{'color': titleTintColor}, bgColor]">
		        <view :style="[{'height': statusBarH + 'px'}]"></view>
				<view class="tabflix">
					<view v-if="isBack" @tap="goBack" class="backicon">
					    <image src="/static/navimg/back.png" style="width: 18upx;height: 30upx;"></image>
					</view>
					<view class="uni_title flex1">
					    {{title}}
					</view>
					<view style="opacity: 0;">1</view>
				</view>
		    </view>
		</view>
		<!-- #ifdef APP-PLUS -->
		<view style="height: 170upx;"></view>
		<!-- #endif -->
		<!-- #ifdef MP-WEIXIN -->
		<view style="height: 150upx;"></view>
		<!-- #endif -->
	</view>
    
</template>
 
<script>
    export default {
        data() {
            return {
                statusBarH: this.statusBar,
                customBarH: this.customBar
            }
        },
        props: {
            isBack: { type: [Boolean, String], default: true },
            title: { type: String, default: '' },
            titleTintColor: { type: String, default: '#fff' },
            bgColor: Object,
            center: { type: [Boolean, String], default: false },
            search: { type: [Boolean, String], default: false },
            searchRadius: { type: [Boolean, String], default: false },
            fixed: { type: [Boolean, String], default: false },
        },
        computed: {
            style() {
				console.log(this.statusBar)
                let _style = `height: ${this.customBarH}px;`
                return _style
            },
        },
        methods: {
            goBack() {
                uni.navigateBack()
            }
        }
    }
</script>
<style scoped lang="scss">
	.uni_topbar{
		box-sizing: border-box;
		position: fixed;
		top: 0;
		width: 100%;
		.tabflix{
			display: flex;
			flex-direction: row;
			box-sizing: border-box;
			padding:27upx 30upx 20upx 30upx;
			/*#ifdef MP-WEIXIN*/
			padding:27upx 30upx 27upx 30upx;
			/*#endif*/
			justify-content: space-between;
			.uni_title{
				font-size: $uni-font-size-36;
			}
		}
	}
	@media (prefers-color-scheme: dark){
	    .inner{
	    	background:linear-gradient(-45deg,$uni-color-201f1f,$uni-color-484646) !important;
	    }
	}
</style>