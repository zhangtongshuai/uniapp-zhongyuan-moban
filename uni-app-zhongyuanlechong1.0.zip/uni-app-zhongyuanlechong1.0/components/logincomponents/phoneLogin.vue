<template>
	<view>
		<view class="uni_topbar">
		    手机号登陆
		</view>
	</view>
    
</template>
 
<script>
    export default {
        data() {
            return {
                
            }
        },
        props: {},
        computed: {
            
        },
        methods: {
            
        }
    }
</script>
<style scoped lang="scss">
	@media (prefers-color-scheme: dark){
	    
	}
</style>